<?php
// Configuración de la conexión a la base de datos
$host = 'localhost';
$dbname = 'sis_escolar';
$username = 'root';
$password = '';

try {
    // Creación de la conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    // Configurar el modo de errores para PDO a Excepción
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>

<<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Escolar</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h2>Bienvenido al Sistema Escolar</h2>
        <p>Selecciona una opción para comenzar:</p>
        <div class="buttons">
            <a href="views/login.php" class="btn">Iniciar Sesión</a>
            <a href="views/registro.php" class="btn">Registrarse</a>
        </div>
    </div>
</body>
</html>

<?php
session_start();
include '../config/db.php';

// Obtener el ID del maestro logueado
$maestro_id = $_SESSION['usuario_id'];

// Consulta para obtener el total de tareas asignadas por el maestro
$sqlTareas = "SELECT COUNT(*) as total_tareas FROM tareas WHERE maestro_id = :maestro_id";
$stmtTareas = $pdo->prepare($sqlTareas);
$stmtTareas->execute([':maestro_id' => $maestro_id]);
$totalTareas = $stmtTareas->fetch(PDO::FETCH_ASSOC)['total_tareas'];

// Consulta para obtener el total de material de apoyo subido por el maestro
$sqlMaterial = "SELECT COUNT(*) as total_material FROM material WHERE maestro_id = :maestro_id";
$stmtMaterial = $pdo->prepare($sqlMaterial);
$stmtMaterial->execute([':maestro_id' => $maestro_id]);
$totalMaterial = $stmtMaterial->fetch(PDO::FETCH_ASSOC)['total_material'];

// Consulta para obtener las notificaciones no leídas del maestro
$sqlNotificaciones = "SELECT * FROM notificaciones WHERE usuario_id = :usuario_id AND leida = FALSE";
$stmtNotificaciones = $pdo->prepare($sqlNotificaciones);
$stmtNotificaciones->execute(['usuario_id' => $maestro_id]);
$notificaciones = $stmtNotificaciones->fetchAll(PDO::FETCH_ASSOC);

// Si se envía el formulario para marcar como leídas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sqlUpdate = "UPDATE notificaciones SET leida = TRUE WHERE usuario_id = :usuario_id";
    $stmtUpdate = $pdo->prepare($sqlUpdate);
    $stmtUpdate->execute(['usuario_id' => $maestro_id]);
    header("Location: dashboard_maestro.php");
    exit();
}
?>

<link rel="stylesheet" href="../css/styles.css">
<div class="admin-dashboard">
    <div class="sidebar">
        <h2>Menú</h2>
        <ul>
            <li><a href="asignar_tarea.php"><img src="../assets/images/asignar_tarea.png" alt="Asignar Tareas" class="menu-icon"> Asignar Tareas</a></li>
            <li><a href="ver_tareas_asignadas.php"><img src="../assets/images/ver_tareas.png" alt="Ver Tareas" class="menu-icon"> Ver Tareas Asignadas</a></li>
            <li><a href="calificar_tarea.php"><img src="../assets/images/calificar.png" alt="Calificar Tareas" class="menu-icon"> Calificar Tareas</a></li>
            <li><a href="subir_material.php"><img src="../assets/images/material.png" alt="Subir Material" class="menu-icon"> Subir Material de Apoyo</a></li>
            <li><a href="ver_material_maestro.php"><img src="../assets/images/ver_material.png" alt="Ver Material" class="menu-icon"> Ver Material Subido</a></li>
            <li><a href="enviar_notificacion.php"><img src="../assets/images/notificacion.png" alt="Notificaciones" class="menu-icon"> Enviar Notificación</a></li>
            <li><a href="ver_notificaciones.php"><img src="../assets/images/notificaciones.png" alt="Ver Notificaciones" class="menu-icon"> Ver Notificaciones</a></li>
            <li><a href="logout.php" class="btn-logout"><img src="../assets/images/logout.png" alt="Cerrar Sesión" class="menu-icon"> Cerrar Sesión</a></li>
        </ul>
    </div>

    <div class="content">
        <h2>Bienvenido al Panel de Control del Maestro</h2>
        <p>Selecciona una opción del menú para comenzar a gestionar tus tareas y materiales.</p>

        <!-- Cuadros Informativos (Estadísticas) -->
        <div class="statistics">
            <div class="stat-box">
                <h3>Tareas Asignadas</h3>
                <p>Total: <span id="total-tareas"><?php echo $totalTareas; ?></span></p>
            </div>
            <div class="stat-box">
                <h3>Material Subido</h3>
                <p>Total: <span id="total-material"><?php echo $totalMaterial; ?></span></p>
            </div>
        </div>

        <!-- Notificaciones -->
        <div class="notifications card">
            <h3>Notificaciones</h3>
            <?php if (!empty($notificaciones)): ?>
                <ul>
                    <?php foreach ($notificaciones as $notificacion): ?>
                        <li><?php echo $notificacion['mensaje']; ?> - <small><?php echo $notificacion['creada_en']; ?></small></li>
                    <?php endforeach; ?>
                </ul>
                <form method="POST" action="">
                    <button type="submit" class="btn-primary">Marcar todas como leídas</button>
                </form>
            <?php else: ?>
                <p>No tienes nuevas notificaciones.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>


<?php
session_start();
include '../config/db.php';

// Consulta para obtener todos los estudiantes
$stmt = $pdo->query("SELECT id, nombre FROM usuarios WHERE rol = 'estudiante'");
$estudiantes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Consulta para obtener todos los cursos
$stmt = $pdo->query("SELECT id, nombre FROM cursos");
$cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Inscribir Estudiante en Curso</h2>
    <div class="course-container">
        <!-- Tabla de Inscripciones -->
        <div class="course-table card">
            <h3>Lista de Estudiantes Inscritos en Cursos</h3>
            <table>
                <thead>
                    <tr>
                        <th>Estudiante</th>
                        <th>Curso</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Consulta para mostrar todas las inscripciones
                    $stmt = $pdo->query("SELECT usuarios.nombre AS estudiante, cursos.nombre AS curso, inscripciones.id
                                         FROM inscripciones
                                         JOIN usuarios ON inscripciones.estudiante_id = usuarios.id
                                         JOIN cursos ON inscripciones.curso_id = cursos.id");
                    $inscripciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($inscripciones as $inscripcion): ?>
                        <tr>
                            <td><?php echo $inscripcion['estudiante']; ?></td>
                            <td><?php echo $inscripcion['curso']; ?></td>
                            <td>
                                <div class="course-actions">
                                    <a href="../controllers/eliminar_inscripcion.php?inscripcion_id=<?php echo $inscripcion['id']; ?>" class="btn-delete" onclick="return confirm('¿Estás seguro de eliminar esta inscripción?')">🗑️ Eliminar</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Formulario para inscribir estudiante -->
        <div class="course-form card">
            <form method="POST" action="../controllers/inscribir_estudiante.php">
                <div class="form-group">
                    <label for="estudiante_id">Seleccionar Estudiante:</label>
                    <select name="estudiante_id" id="estudiante_id" required>
                        <option value="">Seleccionar Estudiante </option>
                        <?php foreach ($estudiantes as $estudiante): ?>
                            <option value="<?php echo $estudiante['id']; ?>"><?php echo $estudiante['nombre']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="curso_id">Seleccionar Curso:</label>
                    <select name="curso_id" id="curso_id" required>
                        <option value="">Seleccionar Curso</option>
                        <?php foreach ($cursos as $curso): ?>
                            <option value="<?php echo $curso['id']; ?>"><?php echo $curso['nombre']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit" class="btn-primary">Inscribir Estudiante</button>
            </form>

            <!-- Botón para volver al Dashboard del Admin -->
            <div class="back-to-dashboard">
                <a href="dashboard_admin.php" class="btn-secondary">Regresar</a>
            </div>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

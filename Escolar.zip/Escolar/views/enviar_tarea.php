<?php
session_start();
include '../config/db.php';

// Obtener el ID del estudiante logueado
$estudiante_id = $_SESSION['usuario_id'];

// Consulta para obtener las tareas junto con el nombre del curso, filtrando por fecha y hora de entrega
$sql = "SELECT tareas.*, cursos.nombre AS curso_nombre 
        FROM tareas 
        JOIN inscripciones ON tareas.curso_id = inscripciones.curso_id
        JOIN cursos ON tareas.curso_id = cursos.id
        WHERE inscripciones.estudiante_id = :estudiante_id
        AND CONCAT(tareas.fecha_entrega, ' ', tareas.hora_entrega) > NOW()";

$stmt = $pdo->prepare($sql);
$stmt->execute([':estudiante_id' => $estudiante_id]);
$tareas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Enviar Tarea</h2>
    <div class="task-upload-form card">
        <form method="POST" action="../controllers/subir_tarea.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="tarea_id">Seleccionar Tarea:</label>
                <select name="tarea_id" id="tarea_id" required>
                    <option value="">-- Seleccionar Tarea --</option>
                    <?php foreach ($tareas as $tarea): ?>
                        <option value="<?php echo $tarea['id']; ?>">
                            <?php echo $tarea['curso_nombre'] . " - " . $tarea['titulo']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="archivo">Subir Tarea (PDF):</label>
                <input type="file" name="archivo" id="archivo" accept=".pdf" required>
            </div>

            <button type="submit" class="btn-primary">Enviar Tarea</button>
        </form>

        <!-- Botón para volver al Dashboard del Estudiante -->
        <div class="back-to-dashboard">
            <a href="dashboard_estudiante.php" class="btn-secondary">Regresar</a>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

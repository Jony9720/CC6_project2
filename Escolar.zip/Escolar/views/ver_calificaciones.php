<?php
session_start();

include '../config/db.php'; // Conexión a la base de datos

// Consulta para obtener las tareas enviadas junto con el nombre del curso, calificaciones y comentarios
$sql = "SELECT tareas.titulo, cursos.nombre AS curso_nombre, envios.fecha_envio, envios.calificacion, envios.comentarios, envios.archivo_ruta
        FROM envios
        JOIN tareas ON envios.tarea_id = tareas.id
        JOIN cursos ON tareas.curso_id = cursos.id
        WHERE envios.estudiante_id = :estudiante_id";

$stmt = $pdo->prepare($sql);
$stmt->execute(['estudiante_id' => $_SESSION['usuario_id']]);
$calificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Mis Calificaciones</h2>

    <?php if (count($calificaciones) > 0): ?>
        <table class="grades-table">
            <thead>
                <tr>
                    <th>Curso</th>
                    <th>Título de la Tarea</th>
                    <th>Fecha de Envío</th>
                    <th>Archivo Enviado</th>
                    <th>Calificación</th>
                    <th>Comentarios</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($calificaciones as $calificacion): ?>
                    <tr>
                        <td><?php echo $calificacion['curso_nombre']; ?></td>
                        <td><?php echo $calificacion['titulo']; ?></td>
                        <td><?php echo $calificacion['fecha_envio']; ?></td>
                        <td><a href="<?php echo $calificacion['archivo_ruta']; ?>" target="_blank" class="btn-view">Ver Archivo</a></td>
                        <td>
                            <?php echo is_null($calificacion['calificacion']) ? '<span class="pending">Pendiente de calificación</span>' : $calificacion['calificacion']; ?>
                        </td>
                        <td><?php echo !empty($calificacion['comentarios']) ? $calificacion['comentarios'] : '<span class="no-comments">Sin comentarios</span>'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="no-grades">No tienes calificaciones disponibles.</p>
    <?php endif; ?>

    <!-- Botón para volver al Dashboard del Estudiante -->
    <div class="back-to-dashboard">
        <a href="dashboard_estudiante.php" class="btn-secondary">Regresar</a>
    </div>
</div>

<?php include '../partials/footer.php'; ?>


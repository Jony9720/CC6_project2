<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Subir Material de Apoyo</h2>

    <!-- Mostrar mensajes de éxito o error si existen -->
    <?php
    session_start();
    if (isset($_SESSION['success_message'])) {
        echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']);
    }

    if (isset($_SESSION['error_message'])) {
        echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']);
    }
    ?>

    <form method="POST" action="../controllers/guardar_material.php" enctype="multipart/form-data">
        <div class="form-group">
            <label for="titulo">Título:</label>
            <input type="text" name="titulo" id="titulo" required>
        </div>

        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea name="descripcion" id="descripcion" required></textarea>
        </div>

        <div class="form-group">
            <label for="curso_id">Seleccionar Curso:</label>
            <select name="curso_id" id="curso_id" required>
                <option value="">-- Seleccionar Curso --</option>
                <?php
                include '../config/db.php';
                $maestro_id = $_SESSION['usuario_id'];
                $stmt = $pdo->prepare("SELECT cursos.id, cursos.nombre FROM cursos
                                       JOIN maestro_cursos ON cursos.id = maestro_cursos.curso_id
                                       WHERE maestro_cursos.maestro_id = :maestro_id");
                $stmt->execute(['maestro_id' => $maestro_id]);
                $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($cursos as $curso) {
                    echo "<option value='{$curso['id']}'>{$curso['nombre']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="tipo">Tipo de Material:</label>
            <select name="tipo" id="tipo" required>
                <option value="archivo">Archivo</option>
                <option value="enlace">Enlace</option>
            </select>
        </div>

        <div id="campo_archivo" class="form-group" style="display: none;">
            <label for="archivo">Subir Archivo:</label>
            <input type="file" name="archivo" id="archivo" accept=".pdf,.ppt,.docx">
        </div>

        <div id="campo_enlace" class="form-group" style="display: none;">
            <label for="enlace">Enlace:</label>
            <input type="url" name="enlace" id="enlace" placeholder="https://">
        </div>

        <button type="submit" class="btn-primary">Subir Material</button>

        <!-- Botón para regresar al Dashboard del Maestro -->
        <div class="back-to-dashboard">
            <a href="dashboard_maestro.php" class="btn-secondary">Regresar</a>
        </div>
    </form>
</div>

<script>
    const tipoSelect = document.getElementById('tipo');
    const campoArchivo = document.getElementById('campo_archivo');
    const campoEnlace = document.getElementById('campo_enlace');

    tipoSelect.addEventListener('change', function() {
        if (tipoSelect.value === 'archivo') {
            campoArchivo.style.display = 'block';
            campoEnlace.style.display = 'none';
        } else if (tipoSelect.value === 'enlace') {
            campoArchivo.style.display = 'none';
            campoEnlace.style.display = 'block';
        }
    });
</script>


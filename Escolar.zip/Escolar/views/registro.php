<?php include '../partials/header.php'; ?>

<div class="login-container">
<h2>Registro de Usuario</h2>
<form method="POST" action="../controllers/registrar.php">
    <input type="text" name="nombre" placeholder="Nombre" required>
    <input type="email" name="correo" placeholder="Correo" required>
    <input type="password" name="password" placeholder="Contraseña" required>
    <select name="rol" required>
        <option value="admin">Administrador</option>
        <option value="maestro">Maestro</option>
        <option value="estudiante">Estudiante</option>
    </select>
    <button type="submit">Registrar</button>
</form>

<div class="back-to-index">
    <a href="../index.php" class="btn">Volver al menú principal</a>
</div>

<?php include '../partials/footer.php'; ?>
</div>

<?php
session_start();

include '../config/db.php'; // Conexión a la base de datos

// Obtener el ID del estudiante logueado
$estudiante_id = $_SESSION['usuario_id'];

// Consulta para obtener las tareas asignadas junto con el nombre del curso
$sql = "SELECT tareas.*, cursos.nombre AS curso_nombre
        FROM tareas
        JOIN inscripciones ON tareas.curso_id = inscripciones.curso_id
        JOIN cursos ON tareas.curso_id = cursos.id
        WHERE inscripciones.estudiante_id = :estudiante_id";

$stmt = $pdo->prepare($sql);
$stmt->execute([':estudiante_id' => $estudiante_id]);
$tareas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Tareas Asignadas</h2>
    <div class="task-container card">
        <table>
            <thead>
                <tr>
                    <th>Curso</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Fecha de Entrega</th>
                    <th>Hora de Entrega</th>
                    <th>Archivo</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($tareas) > 0): ?>
                    <?php foreach ($tareas as $tarea): ?>
                        <tr>
                            <td><?php echo $tarea['curso_nombre']; ?></td>
                            <td><?php echo $tarea['titulo']; ?></td>
                            <td><?php echo $tarea['descripcion']; ?></td>
                            <td><?php echo $tarea['fecha_entrega']; ?></td>
                            <td><?php echo $tarea['hora_entrega']; ?></td>
                            <td>
                                <?php if (!empty($tarea['archivo_instrucciones'])): ?>
                                    <a href="<?php echo $tarea['archivo_instrucciones']; ?>" target="_blank" class="btn-view">Archivo</a>
                                <?php else: ?>
                                    <span class="no-file">Sin archivo</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No tienes tareas asignadas en los cursos en los que estás inscrito.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Botón para regresar al Dashboard del Estudiante -->
    <div class="back-to-dashboard">
        <a href="dashboard_estudiante.php" class="btn-secondary">Regresar</a>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

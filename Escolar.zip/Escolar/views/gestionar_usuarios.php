<?php
session_start();
include '../config/db.php';

// Obtener datos del usuario para editar
$usuario = null;
if (isset($_GET['usuario_id'])) {
    $usuario_id = $_GET['usuario_id'];
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = :usuario_id");
    $stmt->execute([':usuario_id' => $usuario_id]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Obtener todos los usuarios
$stmt = $pdo->query("SELECT * FROM usuarios");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="user-management">
    <h2>Gestión de Usuarios</h2>
    <div class="user-container">
        <!-- Tabla de usuarios -->
        <div class="user-table card">
            <h3>Lista de Usuarios</h3>
            <table>
            <?php
            // Mostrar mensajes de éxito o error
            if (isset($_SESSION['success_message'])) {
                echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
                unset($_SESSION['success_message']);
            }

            if (isset($_SESSION['error_message'])) {
                echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
                unset($_SESSION['error_message']);
            }
            ?>


                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Rol</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $usuario_item): ?>
                        <tr>
                            <td><?php echo $usuario_item['nombre']; ?></td>
                            <td><?php echo $usuario_item['correo']; ?></td>
                            <td><?php echo ucfirst($usuario_item['rol']); ?></td>
                            <td>
                                <a href="gestionar_usuarios.php?usuario_id=<?php echo $usuario_item['id']; ?>" class="btn-edit">✏️ Editar</a>
                                <span class="btn-separator"></span>
                                <a href="../controllers/eliminar_usuario.php?usuario_id=<?php echo $usuario_item['id']; ?>" class="btn-delete" onclick="return confirm('¿Estás seguro de eliminar este usuario?')">🗑️ Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Formulario para crear o editar usuario -->
        <div class="user-form card">
            <form method="POST" action="../controllers/guardar_usuario.php">
                <input type="hidden" name="usuario_id" value="<?php echo isset($usuario['id']) ? $usuario['id'] : ''; ?>">

                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" name="nombre" id="nombre" value="<?php echo isset($usuario['nombre']) ? $usuario['nombre'] : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="correo">Correo Electrónico:</label>
                    <input type="email" name="correo" id="correo" value="<?php echo isset($usuario['correo']) ? $usuario['correo'] : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input type="password" name="password" id="password" <?php echo isset($usuario) ? '' : 'required'; ?>>
                </div>

                <div class="form-group">
                    <label for="rol">Rol:</label>
                    <select name="rol" id="rol" required>
                        <option value="administrador" <?php echo isset($usuario['rol']) && $usuario['rol'] == 'administrador' ? 'selected' : ''; ?>>Administrador</option>
                        <option value="maestro" <?php echo isset($usuario['rol']) && $usuario['rol'] == 'maestro' ? 'selected' : ''; ?>>Maestro</option>
                        <option value="estudiante" <?php echo isset($usuario['rol']) && $usuario['rol'] == 'estudiante' ? 'selected' : ''; ?>>Estudiante</option>
                    </select>
                </div>

                <button type="submit" class="btn-primary"><?php echo isset($usuario) ? 'Actualizar Usuario' : 'Crear Usuario'; ?></button>
            </form>

            <!-- Botón para volver al Dashboard del Admin -->
            <div class="back-to-dashboard">
                <a href="dashboard_admin.php" class="btn-secondary">Regresar</a>
            </div>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

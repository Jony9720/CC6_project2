<?php
session_start();
include '../config/db.php';

// Verificar si el usuario es maestro
if ($_SESSION['rol'] !== 'maestro') {
    echo "Acceso denegado.";
    exit();
}



$maestro_id = $_SESSION['usuario_id'];

// ID del curso seleccionado para el filtro
$curso_id = $_GET['curso_id'] ?? null;

// Consulta para obtener el material de apoyo subido por el maestro
$sql = "SELECT material.*, cursos.nombre AS curso 
        FROM material 
        JOIN cursos ON material.curso_id = cursos.id
        WHERE material.maestro_id = :maestro_id";

$params = [':maestro_id' => $maestro_id];

// Filtro opcional por curso
if ($curso_id) {
    $sql .= " AND material.curso_id = :curso_id";
    $params[':curso_id'] = $curso_id;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$materiales = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener los cursos para el filtro
$cursos = $pdo->prepare("SELECT id, nombre FROM cursos WHERE id IN (SELECT curso_id FROM maestro_cursos WHERE maestro_id = :maestro_id)");
$cursos->execute([':maestro_id' => $maestro_id]);
$cursos = $cursos->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Material de Apoyo Subido</h2>
    <?php
    // Mostrar mensajes si existen en la URL

    if (isset($_GET['message']) && isset($_GET['text'])) {
        $messageType = $_GET['message'];
        $messageText = urldecode($_GET['text']);
        echo '<div class="message ' . ($messageType === 'success' ? 'success' : 'error') . '">' . $messageText . '</div>';
    }
    ?>
    <!-- Filtro de Curso -->
    <form method="GET" action="ver_material_maestro.php" class="filter-form">
        <div class="form-group">
            <label for="curso_id">Filtrar por Curso:</label>
            <select name="curso_id" id="curso_id">
                <option value="">Todos los Cursos</option>
                <?php foreach ($cursos as $curso): ?>
                    <option value="<?php echo $curso['id']; ?>" <?php echo $curso_id == $curso['id'] ? 'selected' : ''; ?>>
                        <?php echo $curso['nombre']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-primary">Aplicar Filtro</button>
        </div>
    </form>

    <!-- Tabla de Material de Apoyo -->
    <table class="material-table">
        <thead>
            <tr>
                <th>Título</th>
                <th>Descripción</th>
                <th>Curso</th>
                <th>Tipo</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($materiales) > 0): ?>
                <?php foreach ($materiales as $material): ?>
                    <tr>
                        <td><?php echo $material['titulo']; ?></td>
                        <td><?php echo $material['descripcion']; ?></td>
                        <td><?php echo $material['curso']; ?></td>
                        <td><?php echo ucfirst($material['tipo']); ?></td>
                        <td>
                            <?php if ($material['tipo'] == 'archivo'): ?>
                                <a href="<?php echo $material['archivo_ruta']; ?>" target="_blank" class="btn-view">Archivo</a>
                            <?php elseif ($material['tipo'] == 'enlace'): ?>
                                <a href="<?php echo $material['enlace']; ?>" target="_blank" class="btn-view">Vínculo</a>
                            <?php endif; ?>
                            <a href="../controllers/eliminar_material.php?material_id=<?php echo $material['id']; ?>" class="btn-delete" onclick="return confirm('¿Estás seguro de eliminar este material?')">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="no-material">No has subido material de apoyo aún.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Botón para volver al Dashboard del Maestro -->
    <div class="back-to-dashboard">
        <a href="dashboard_maestro.php" class="btn-secondary">Regresar</a>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

<?php
session_start();
include '../config/db.php';

// Consulta para obtener todos los usuarios
$stmt = $pdo->query("SELECT id, nombre, rol FROM usuarios");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Verificar si hay un mensaje de éxito en la URL
$mensaje_exito = isset($_GET['mensaje']) ? $_GET['mensaje'] : '';
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="notification-management">
    <h2>Enviar Notificación</h2>
    <div class="notification-container">
        <!-- Mostrar mensaje de éxito -->
        <?php if ($mensaje_exito): ?>
            <div class="alert alert-success text-center">
                <?php echo htmlspecialchars($mensaje_exito); ?>
            </div>
        <?php endif; ?>

        <!-- Formulario para enviar una notificación -->
        <div class="notification-form card">
            <form method="POST" action="../controllers/enviar_notificacion.php">
                <div class="form-group">
                    <label for="mensaje">Mensaje:</label>
                    <textarea name="mensaje" id="mensaje" required></textarea>
                </div>

                <div class="form-group">
                    <label for="usuario_id">Seleccionar Destinatario:</label>
                    <select name="usuario_id" id="usuario_id" required>
                        <option value="">-- Seleccionar Usuario --</option>
                        <?php foreach ($usuarios as $usuario): ?>
                            <option value="<?php echo $usuario['id']; ?>">
                                <?php echo $usuario['nombre']; ?> (<?php echo $usuario['rol']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <button type="submit" class="btn-primary">Enviar Notificación</button>
            </form>

            <!-- Botón para volver al Dashboard del Admin o Maestro -->
            <div class="back-to-dashboard">
                <?php
                if (isset($_SESSION['rol'])) {
                    if ($_SESSION['rol'] === 'admin') {
                        echo '<a href="dashboard_admin.php" class="btn-secondary">Regresar</a>';
                    } elseif ($_SESSION['rol'] === 'maestro') {
                        echo '<a href="dashboard_maestro.php" class="btn-secondary">Regresar</a>';
                    } elseif ($_SESSION['rol'] === 'estudiante') {
                        echo '<a href="dashboard_estudiante.php" class="btn-secondary">Regresar</a>';
                    }else {
                        // Rol desconocido, regresar al inicio por defecto
                        echo '<a href="index.php" class="btn-secondary">Regresar al Inicio</a>';
                    }
                } else {
                    // Si no existe el rol en la sesión, redirigir al inicio
                    echo '<a href="index.php" class="btn-secondary">Regresar al Inicio</a>';
                }
                ?>
            </div>

        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>    


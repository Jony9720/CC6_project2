<?php
session_start();
include '../config/db.php';

// Obtener los datos del usuario logueado
$usuario_id = $_SESSION['usuario_id'];
$stmt = $pdo->prepare("SELECT nombre, correo FROM usuarios WHERE id = :usuario_id");
$stmt->execute([':usuario_id' => $usuario_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    echo "Error al obtener los datos del perfil.";
    exit();
}
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="profile-container card">
    <h2>Mi Perfil</h2>
    <div class="profile-info">
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombre']); ?></p>
        <p><strong>Correo:</strong> <?php echo htmlspecialchars($usuario['correo']); ?></p>
    </div>
    <div class="back-to-dashboard">
        <a href="dashboard_estudiante.php" class="btn-secondary">Regresar al Dashboard</a>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

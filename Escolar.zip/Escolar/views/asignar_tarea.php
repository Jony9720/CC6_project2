<?php
session_start();
include '../config/db.php';

// Obtener el ID del profesor logueado
$maestro_id = $_SESSION['usuario_id'];

// Consulta para obtener los cursos que el maestro tiene asignados
$sql = "SELECT cursos.id, cursos.nombre 
        FROM cursos 
        JOIN maestro_cursos ON cursos.id = maestro_cursos.curso_id
        WHERE maestro_cursos.maestro_id = :maestro_id";

$stmt = $pdo->prepare($sql);
$stmt->execute([':maestro_id' => $maestro_id]);
$cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>



<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Asignar Tarea</h2>
    <div class="task-form card">
            <?php
            // Mostrar mensajes de éxito o error si existen
            if (isset($_SESSION['success_message'])) {
                echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
                unset($_SESSION['success_message']);
            }

            if (isset($_SESSION['error_message'])) {
                echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
                unset($_SESSION['error_message']);
            }
            ?>
        <form method="POST" action="../controllers/guardar_tarea.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="titulo">Título de la Tarea:</label>
                <input type="text" name="titulo" id="titulo" placeholder="Ingrese el título de la tarea" required>
            </div>

            <div class="form-group">
                <label for="descripcion">Descripción:</label>
                <textarea name="descripcion" id="descripcion" placeholder="Ingrese la descripción de la tarea" required></textarea>
            </div>

            <div class="form-group">
                <label for="fecha_entrega">Fecha de Entrega:</label>
                <input type="date" name="fecha_entrega" id="fecha_entrega" required>
            </div>

            <div class="form-group">
                <label for="hora_entrega">Hora de Entrega:</label>
                <input type="time" name="hora_entrega" id="hora_entrega" required>
            </div>

            <div class="form-group">
                <label for="curso_id">Seleccionar Curso:</label>
                <select name="curso_id" id="curso_id" required>
                    <option value="">-- Seleccionar Curso --</option>
                    <?php foreach ($cursos as $curso): ?>
                        <option value="<?php echo $curso['id']; ?>"><?php echo $curso['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Campo para subir archivo -->
            <div class="form-group">
                <label for="archivo_instrucciones">Subir Archivo de Instrucciones:</label>
                <input type="file" name="archivo_instrucciones" id="archivo_instrucciones" accept=".pdf, .doc, .docx, .ppt, .pptx, .zip">
            </div>

            <button type="submit" class="btn-primary">Asignar Tarea</button>

            <!-- Botón para volver al Dashboard del Maestro -->
            <div class="back-to-dashboard">
                <a href="dashboard_maestro.php" class="btn-secondary">Regresar</a>
            </div>
        </form>
    </div>
</div>

<?php include '../partials/footer.php'; ?>


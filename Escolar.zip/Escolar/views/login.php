<?php include '../partials/header.php'; ?>
<?php session_start(); ?>
<div class="login-container">
<h2>Inicio de Sesión</h2>

<?php if (isset($_SESSION['success'])): ?>
    <div class="message success"><?php echo $_SESSION['success']; ?></div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="message error"><?php echo $_SESSION['error']; ?></div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<form method="POST" action="../controllers/autenticar.php">
    <input type="email" name="correo" placeholder="Correo" required>
    <input type="password" name="password" placeholder="Contraseña" required>
    <button type="btn">Iniciar Sesión</button>
</form>

<div class="back-to-index">
    <a href="../index.php" class="btn">Volver al menú principal</a>
</div>

<?php include '../partials/footer.php'; ?>
</div>

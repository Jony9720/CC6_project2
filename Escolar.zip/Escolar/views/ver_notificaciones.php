<?php
session_start();

include '../config/db.php';

// Obtener las notificaciones del usuario actual
$usuario_id = $_SESSION['usuario_id'];
$stmt = $pdo->prepare("SELECT * FROM notificaciones WHERE usuario_id = :usuario_id ORDER BY creada_en DESC");
$stmt->execute([':usuario_id' => $usuario_id]);
$notificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Mis Notificaciones</h2>

    <!-- Tabla de Notificaciones -->
    <table class="notifications-table">
        <thead>
            <tr>
                <th>Mensaje</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($notificaciones) > 0): ?>
                <?php foreach ($notificaciones as $notificacion): ?>
                    <tr class="<?php echo $notificacion['leida'] ? 'read' : 'unread'; ?>">
                        <td><?php echo $notificacion['mensaje']; ?></td>
                        <td><?php echo $notificacion['creada_en']; ?></td>
                        <td><?php echo $notificacion['leida'] ? 'Leída' : 'No leída'; ?></td>
                        <td>
                            <?php if (!$notificacion['leida']): ?>
                                <a href="../controllers/marcar_leida.php?notificacion_id=<?php echo $notificacion['id']; ?>" class="btn-mark-read">Marcar como Leída</a>
                            <?php else: ?>
                                <span class="read-text">Leída</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No tienes notificaciones.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Botón para volver al Dashboard -->
    <div class="back-to-dashboard">
        <?php if ($_SESSION['rol'] === 'estudiante'): ?>
            <a href="dashboard_estudiante.php" class="btn-secondary">Regresar</a>
        <?php elseif ($_SESSION['rol'] === 'maestro'): ?>
            <a href="dashboard_maestro.php" class="btn-secondary">Regresar</a>
        <?php elseif ($_SESSION['rol'] === 'admin'): ?>
             <a href="dashboard_admin.php" class="btn-secondary">Regresar</a>
        <?php endif; ?>
    </div>

</div>

<?php include '../partials/footer.php'; ?>


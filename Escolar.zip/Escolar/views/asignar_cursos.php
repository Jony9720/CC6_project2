<?php
include '../config/db.php';
?>


<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Asignar Cursos a Maestros</h2>
    <div class="course-container">
        <!-- Tabla de Cursos Asignados -->
        <div class="course-table card">
            <h3>Lista de Cursos Asignados</h3>
            <table>
                <thead>
                    <tr>
                        <th>Maestro</th>
                        <th>Curso</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Consulta para mostrar todas las asignaciones
                    $stmt = $pdo->query("SELECT usuarios.nombre AS maestro, cursos.nombre AS curso, maestro_cursos.id
                                         FROM maestro_cursos
                                         JOIN usuarios ON maestro_cursos.maestro_id = usuarios.id
                                         JOIN cursos ON maestro_cursos.curso_id = cursos.id");
                    $asignaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if (count($asignaciones) > 0) {
                        foreach ($asignaciones as $asignacion): ?>
                            <tr>
                                <td><?php echo $asignacion['maestro']; ?></td>
                                <td><?php echo $asignacion['curso']; ?></td>
                                <td>
                                    <a href="../controllers/eliminar_asignacion.php?asignacion_id=<?php echo $asignacion['id']; ?>" class="btn-delete" onclick="return confirm('¿Estás seguro de eliminar esta asignación?')">🗑️ Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach;
                    } else {
                        echo "<tr><td colspan='3'>No hay asignaciones.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- Formulario para Asignar Curso -->
        <div class="course-form card">
            <form method="POST" action="../controllers/asignar_cursos.php">
                <div class="form-group">
                    <label for="maestro_id">Seleccionar Maestro:</label>
                    <select name="maestro_id" id="maestro_id" required>
                        <option value="">Seleccionar Maestro</option>
                        <?php
                        $maestros = $pdo->query("SELECT id, nombre FROM usuarios WHERE rol = 'maestro'")->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($maestros as $maestro) {
                            echo "<option value='{$maestro['id']}'>{$maestro['nombre']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="curso_id">Seleccionar Curso:</label>
                    <select name="curso_id" id="curso_id" required>
                        <option value="">Seleccionar Curso</option>
                        <?php
                        $cursos = $pdo->query("SELECT id, nombre FROM cursos")->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($cursos as $curso) {
                            echo "<option value='{$curso['id']}'>{$curso['nombre']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <button type="submit" class="btn-primary">Asignar Curso</button>
            </form>

            <!-- Botón para volver al Dashboard del Admin -->
            <div class="back-to-dashboard">
                <a href="dashboard_admin.php" class="btn-secondary">Regresar</a>
            </div>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

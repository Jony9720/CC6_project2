<?php
session_start();
include '../config/db.php'; // Conexión a la base de datos

// Verificar si el usuario es estudiante
if ($_SESSION['rol'] !== 'estudiante') {
    echo "Acceso denegado.";
    exit();
}

$estudiante_id = $_SESSION['usuario_id'];

// Consulta para obtener los cursos en los que el estudiante está inscrito
$sql = "SELECT cursos.nombre, cursos.descripcion
        FROM inscripciones
        JOIN cursos ON inscripciones.curso_id = cursos.id
        WHERE inscripciones.estudiante_id = :estudiante_id";

$stmt = $pdo->prepare($sql);
$stmt->execute([':estudiante_id' => $estudiante_id]);
$cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Mis Cursos Inscritos</h2>
    <div class="task-container card">
        <?php if (count($cursos) > 0): ?>
            <div class="course-table card">
                <table>
                    <thead>
                        <tr>
                            <th>Nombre del Curso</th>
                            <th>Descripción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cursos as $curso): ?>
                            <tr>
                                <td><?php echo $curso['nombre']; ?></td>
                                <td><?php echo $curso['descripcion']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="card">
                <p>No estás inscrito en ningún curso.</p>
            </div>
        <?php endif; ?>

        <!-- Botón para regresar al Dashboard del Estudiante -->
        <div class="back-to-dashboard">
            <a href="dashboard_estudiante.php" class="btn-secondary">Regresar</a>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

<?php
session_start();
include '../config/db.php';

if ($_SESSION['rol'] !== 'maestro') {
    echo "Acceso denegado.";
    exit();
}

$maestro_id = $_SESSION['usuario_id'];

$sql = "SELECT envios.*, tareas.titulo AS tarea_titulo, usuarios.nombre AS estudiante_nombre 
        FROM envios
        JOIN tareas ON envios.tarea_id = tareas.id
        JOIN usuarios ON envios.estudiante_id = usuarios.id
        WHERE tareas.maestro_id = :maestro_id";

$stmt = $pdo->prepare($sql);
$stmt->execute([':maestro_id' => $maestro_id]);
$envios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>



<link rel="stylesheet" href="../css/styles.css">
<div class="course-management">
    <h2>Calificar Tareas</h2>

    <?php
    if (isset($_SESSION['success_message'])) {
        echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']);
    }
    ?>

    <div class="task-table card">
        <table>
            <thead>
                <tr>
                    <th>Estudiante</th>
                    <th>Tarea</th>
                    <th>Archivo</th>
                    <th>Fecha de Envío</th>
                    <th>Calificación</th>
                    <th>Comentarios</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($envios as $envio): ?>
                    <tr>
                        <td><?php echo $envio['estudiante_nombre']; ?></td>
                        <td><?php echo $envio['tarea_titulo']; ?></td>
                        <td><a href="<?php echo $envio['archivo_ruta']; ?>" target="_blank">Ver archivo</a></td>
                        <td><?php echo $envio['fecha_envio']; ?></td>
                        <form method="POST" action="../controllers/guardar_calificacion.php">
                            <td>
                                <input type="number" name="calificacion" value="<?php echo $envio['calificacion']; ?>" min="0" max="100" required class="input-grade">
                            </td>
                            <td>
                                <textarea name="comentarios" class="input-comments"><?php echo $envio['comentarios']; ?></textarea>
                            </td>
                            <td>
                                <input type="hidden" name="envio_id" value="<?php echo $envio['id']; ?>">
                                <button type="submit" class="btn-primary">Guardar</button>
                            </td>
                            
                        </form>
                    </tr>
                <?php endforeach; ?>
                
            </tbody>
        </table>
        <!-- Botón para regresar al Dashboard del Maestro -->
        <div class="back-to-dashboard">
                                <a href="dashboard_maestro.php" class="btn-secondary">Regresar</a>
                            </div>
    </div>
</div>



<?php include '../partials/footer.php'; ?>


<?php
session_start();
include '../config/db.php';

// Consulta para obtener las notificaciones no leídas del estudiante
$sql = "SELECT * FROM notificaciones WHERE usuario_id = :usuario_id AND leida = FALSE";
$stmt = $pdo->prepare($sql);
$stmt->execute(['usuario_id' => $_SESSION['usuario_id']]);
$notificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Si se envía el formulario para marcar como leído
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sql = "UPDATE notificaciones SET leida = TRUE WHERE usuario_id = :usuario_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['usuario_id' => $_SESSION['usuario_id']]);
    header("Location: dashboard_estudiante.php");
    exit();
}
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="admin-dashboard">
    <div class="sidebar">
        <h2>Menú</h2>
        <ul>
            <li><a href="ver_perfil.php"><img src="../assets/images/perfil.png" alt="Perfil" class="menu-icon"> Ver Perfil</a></li>
            <li><a href="ver_cursos.php"><img src="../assets/images/cursos.png" alt="Cursos" class="menu-icon"> Mis Cursos</a></li>
            <li><a href="ver_tareas.php"><img src="../assets/images/tareas.png" alt="Tareas" class="menu-icon"> Ver Tareas Asignadas</a></li>
            <li><a href="enviar_tarea.php"><img src="../assets/images/enviar.png" alt="Enviar Tarea" class="menu-icon"> Enviar Tarea</a></li>
            <li><a href="ver_calificaciones.php"><img src="../assets/images/calificaciones.png" alt="Calificaciones" class="menu-icon"> Ver Calificaciones</a></li>
            <li><a href="ver_material.php"><img src="../assets/images/material.png" alt="Material" class="menu-icon"> Ver Material de Apoyo</a></li>
            <li><a href="enviar_notificacion.php"><img src="../assets/images/notificacion.png" alt="Usuarios" class="menu-icon">Enviar una Notificación</a></li>
            <li><a href="ver_notificaciones.php"><img src="../assets/images/notificaciones.png" alt="Notificaciones" class="menu-icon"> Mis Notificaciones</a></li>
            <li><a href="logout.php" class="btn-logout"><img src="../assets/images/logout.png" alt="Cerrar Sesión" class="menu-icon"> Cerrar Sesión</a></li>
        </ul>
    </div>
    <div class="content">
        <h2>Bienvenido al Panel de Control del Estudiante</h2>
        <p>Selecciona una opción del menú para comenzar a gestionar tus actividades.</p>

        <!-- Notificaciones -->
        <div class="notifications card">
            <h3>Notificaciones</h3>
            <?php if (!empty($notificaciones)): ?>
                <ul>
                    <?php foreach ($notificaciones as $notificacion): ?>
                        <li><?php echo $notificacion['mensaje']; ?> - <small><?php echo $notificacion['creada_en']; ?></small></li>
                    <?php endforeach; ?>
                </ul>
                <form method="POST" action="">
                    <button type="submit" class="btn-primary">Marcar todas como leídas</button>
                </form>
            <?php else: ?>
                <p>No tienes nuevas notificaciones.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>


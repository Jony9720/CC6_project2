<?php
session_start();
include '../config/db.php';

// Obtener datos del curso para editar
$curso = null;
if (isset($_GET['curso_id'])) {
    $curso_id = $_GET['curso_id'];
    $stmt = $pdo->prepare("SELECT * FROM cursos WHERE id = :curso_id");
    $stmt->execute([':curso_id' => $curso_id]);
    $curso = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Obtener todos los cursos
$stmt = $pdo->query("SELECT * FROM cursos");
$cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Gestión de Cursos</h2>
    <div class="course-container">
        <!-- Tabla de cursos -->
        <div class="course-table card">
            <h3>Cursos Existentes</h3>
            <?php
            // Mostrar mensajes de éxito o error
            if (isset($_SESSION['success_message'])) {
                echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
                unset($_SESSION['success_message']);
            }

            if (isset($_SESSION['error_message'])) {
                echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
                unset($_SESSION['error_message']);
            }
            ?>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cursos as $curso_item): ?>
                        <tr>
                            <td><?php echo $curso_item['nombre']; ?></td>
                            <td><?php echo $curso_item['descripcion']; ?></td>
                            <td>
                            <div class="course-actions">
                                <a href="gestionar_cursos.php?curso_id=<?php echo $curso_item['id']; ?>" class="btn-edit">✏️ Editar</a>
                                <span class="btn-separator"></span>
                                <a href="../controllers/eliminar_curso.php?curso_id=<?php echo $curso_item['id']; ?>" class="btn-delete" onclick="return confirm('¿Estás seguro de eliminar este curso?')">🗑️ Eliminar</a>
                            </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Formulario para crear o editar curso -->
        <div class="course-form card">
            <form method="POST" action="../controllers/guardar_curso.php">
                <input type="hidden" name="curso_id" value="<?php echo isset($curso['id']) ? $curso['id'] : ''; ?>">

                <div class="form-group">
                    <label for="nombre">Nombre del Curso:</label>
                    <input type="text" name="nombre" id="nombre" value="<?php echo isset($curso['nombre']) ? $curso['nombre'] : ''; ?>" required>
                </div>

                <div class="form-group">
                    <label for="descripcion">Descripción del Curso:</label>
                    <textarea name="descripcion" id="descripcion" required><?php echo isset($curso['descripcion']) ? $curso['descripcion'] : ''; ?></textarea>
                </div>

                <button type="submit" class="btn-primary"><?php echo isset($curso) ? 'Actualizar Curso' : 'Crear Curso'; ?></button>
            </form>

            <!-- Botón para volver al Dashboard del Admin -->
            <div class="back-to-dashboard">
                <a href="dashboard_admin.php" class="btn-secondary">Regresar</a>
            </div>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

<?php
session_start();

include '../config/db.php';

// Obtener el ID del estudiante logueado
$estudiante_id = $_SESSION['usuario_id'];

// ID del curso seleccionado (para el filtro)
$curso_id = $_GET['curso_id'] ?? null;

// Consulta para obtener solo los materiales de los cursos en los que el estudiante está inscrito
$sql = "SELECT material.*, cursos.nombre as curso, usuarios.nombre as maestro 
        FROM material 
        JOIN cursos ON material.curso_id = cursos.id
        JOIN usuarios ON material.maestro_id = usuarios.id
        JOIN inscripciones ON material.curso_id = inscripciones.curso_id
        WHERE inscripciones.estudiante_id = :estudiante_id";

$params = [':estudiante_id' => $estudiante_id];

if ($curso_id) {
    $sql .= " AND material.curso_id = :curso_id";
    $params[':curso_id'] = $curso_id;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$materiales = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener los cursos para el filtro
$cursos = $pdo->prepare("SELECT cursos.id, cursos.nombre 
                         FROM cursos 
                         JOIN inscripciones ON cursos.id = inscripciones.curso_id
                         WHERE inscripciones.estudiante_id = :estudiante_id");
$cursos->execute([':estudiante_id' => $estudiante_id]);
$cursos = $cursos->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Material de Apoyo</h2>

    <!-- Filtro de Curso -->
    <form method="GET" action="ver_material.php" class="filter-form">
        <div class="form-group">
            <label for="curso_id">Filtrar por Curso:</label>
            <select name="curso_id" id="curso_id">
                <option value="">Todos los Cursos</option>
                <?php foreach ($cursos as $curso): ?>
                    <option value="<?php echo $curso['id']; ?>" <?php echo $curso_id == $curso['id'] ? 'selected' : ''; ?>>
                        <?php echo $curso['nombre']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-primary">Aplicar Filtro</button>
        </div>
    </form>

    <!-- Tabla de Material de Apoyo -->
    <table class="material-table">
        <thead>
            <tr>
                <th>Título</th>
                <th>Descripción</th>
                <th>Curso</th>
                <th>Maestro</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($materiales) > 0): ?>
                <?php foreach ($materiales as $material): ?>
                    <tr>
                        <td><?php echo $material['titulo']; ?></td>
                        <td><?php echo $material['descripcion']; ?></td>
                        <td><?php echo $material['curso']; ?></td>
                        <td><?php echo $material['maestro']; ?></td>
                        <td>
                            <?php if ($material['tipo'] == 'archivo'): ?>
                                <a href="<?php echo $material['archivo_ruta']; ?>" target="_blank" class="btn-view">Descargar</a>
                            <?php elseif ($material['tipo'] == 'enlace'): ?>
                                <a href="<?php echo $material['enlace']; ?>" target="_blank" class="btn-view">Ver Enlace</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="no-material">No tienes material de apoyo disponible en los cursos en los que estás inscrito.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Botón para volver al Dashboard del Estudiante -->
    <div class="back-to-dashboard">
        <a href="dashboard_estudiante.php" class="btn-secondary">Regresar</a>
    </div>
</div>

<?php include '../partials/footer.php'; ?>


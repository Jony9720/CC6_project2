<?php
session_start();
include '../config/db.php'; // Incluye la conexión a la base de datos

// Obtener la cantidad de estudiantes
$sqlEstudiantes = "SELECT COUNT(*) as total FROM usuarios WHERE rol = 'estudiante'";
$stmtEstudiantes = $pdo->prepare($sqlEstudiantes);
$stmtEstudiantes->execute();
$totalEstudiantes = $stmtEstudiantes->fetch(PDO::FETCH_ASSOC)['total'];

// Obtener la cantidad de cursos
$sqlCursos = "SELECT COUNT(*) as total FROM cursos";
$stmtCursos = $pdo->prepare($sqlCursos);
$stmtCursos->execute();
$totalCursos = $stmtCursos->fetch(PDO::FETCH_ASSOC)['total'];

// Obtener la cantidad de maestros
$sqlMaestros = "SELECT COUNT(*) as total FROM usuarios WHERE rol = 'maestro'";
$stmtMaestros = $pdo->prepare($sqlMaestros);
$stmtMaestros->execute();
$totalMaestros = $stmtMaestros->fetch(PDO::FETCH_ASSOC)['total'];

// Consulta para obtener las notificaciones no leídas del administrador
$sqlNotificaciones = "SELECT * FROM notificaciones WHERE usuario_id = :usuario_id AND leida = FALSE";
$stmtNotificaciones = $pdo->prepare($sqlNotificaciones);
$stmtNotificaciones->execute(['usuario_id' => $_SESSION['usuario_id']]);
$notificaciones = $stmtNotificaciones->fetchAll(PDO::FETCH_ASSOC);

// Marcar notificaciones como leídas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sqlUpdate = "UPDATE notificaciones SET leida = TRUE WHERE usuario_id = :usuario_id";
    $stmtUpdate = $pdo->prepare($sqlUpdate);
    $stmtUpdate->execute(['usuario_id' => $_SESSION['usuario_id']]);
    header("Location: dashboard_admin.php");
    exit();
}
?>

<link rel="stylesheet" href="../css/styles.css">
<div class="admin-dashboard">
    <div class="sidebar">
        <h2>Menú</h2>
        <ul>
            <li><a href="gestionar_usuarios.php"><img src="../assets/images/usuario.png" alt="Usuarios" class="menu-icon"> Gestionar Usuarios</a></li>
            <li><a href="gestionar_cursos.php"><img src="../assets/images/cursos.png" alt="Cursos" class="menu-icon">Gestionar Cursos</a></li>
            <li><a href="inscribir_estudiante.php"><img src="../assets/images/inscripcion.png" alt="Inscripción" class="menu-icon">Gestionar Inscripciones</a></li>
            <li><a href="asignar_cursos.php"><img src="../assets/images/asignar.png" alt="Asignar Cursos" class="menu-icon">Asignar Cursos a Maestros</a></li>
            <li><a href="enviar_notificacion.php"><img src="../assets/images/notificacion.png" alt="Notificaciones" class="menu-icon">Enviar una Notificación</a></li>
            <li><a href="ver_notificaciones.php"><img src="../assets/images/notificaciones.png" alt="Ver Notificaciones" class="menu-icon">Ver Notificaciones</a></li>
            <li><a href="logout.php" class="btn-logout"><img src="../assets/images/logout.png" alt="Cerrar Sesión" class="menu-icon">Cerrar Sesión</a></li>
        </ul>
    </div>
    <div class="content">
        <h2>Bienvenido al Panel de Control del Administrador</h2>
        <p>Selecciona una opción del menú para comenzar a gestionar el sistema.</p>

        <!-- Cuadros Informativos (Estadísticas) -->
        <div class="statistics">
            <div class="stat-box">
                <h3>Total Estudiantes</h3>
                <p><?php echo $totalEstudiantes; ?></p>
            </div>
            <div class="stat-box">
                <h3>Total Cursos</h3>
                <p><?php echo $totalCursos; ?></p>
            </div>
            <div class="stat-box">
                <h3>Total Maestros</h3>
                <p><?php echo $totalMaestros; ?></p>
            </div>
        </div>

        <!-- Notificaciones -->
        <div class="notifications card" style="margin-top: 20px;">
            <h3>Notificaciones</h3>
            <?php if (!empty($notificaciones)): ?>
                <ul>
                    <?php foreach ($notificaciones as $notificacion): ?>
                        <li><?php echo $notificacion['mensaje']; ?> - <small><?php echo $notificacion['creada_en']; ?></small></li>
                    <?php endforeach; ?>
                </ul>
                <form method="POST" action="">
                    <button type="submit" class="btn-primary">Marcar todas como leídas</button>
                </form>
            <?php else: ?>
                <p>No tienes nuevas notificaciones.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../partials/footer.php'; ?>



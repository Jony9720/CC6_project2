<?php
session_start();
include '../config/db.php';

// Verificar si el usuario es maestro
if ($_SESSION['rol'] !== 'maestro') {
    echo "Acceso denegado.";
    exit();
}

$maestro_id = $_SESSION['usuario_id'];

// Consulta para obtener las tareas asignadas por el maestro
$sql = "SELECT tareas.*, cursos.nombre AS curso_nombre, tareas.archivo_instrucciones
        FROM tareas
        JOIN cursos ON tareas.curso_id = cursos.id
        WHERE tareas.maestro_id = :maestro_id";

$stmt = $pdo->prepare($sql);
$stmt->execute([':maestro_id' => $maestro_id]);
$tareas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="course-management">
    <h2>Tareas Asignadas</h2>

    <?php
    // Mostrar mensajes de éxito o error si existen
    if (isset($_SESSION['success_message'])) {
        echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']); // Eliminar el mensaje de la sesión
    }

    if (isset($_SESSION['error_message'])) {
        echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']); // Eliminar el mensaje de la sesión
    }
    ?>

    <!-- Tabla para mostrar las tareas asignadas -->
    <table class="task-table">
        <thead>
            <tr>
                <th>Título</th>
                <th>Descripción</th>
                <th>Curso</th>
                <th>Fecha de Entrega</th>
                <th>Hora de Entrega</th>
                <th>Archivo</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($tareas) > 0): ?>
                <?php foreach ($tareas as $tarea): ?>
                    <tr>
                        <td><?php echo $tarea['titulo']; ?></td>
                        <td><?php echo $tarea['descripcion']; ?></td>
                        <td><?php echo $tarea['curso_nombre']; ?></td>
                        <td><?php echo $tarea['fecha_entrega']; ?></td>
                        <td><?php echo $tarea['hora_entrega']; ?></td>
                        <td>
                            <?php if (!empty($tarea['archivo_instrucciones'])): ?>
                                <a href="<?php echo $tarea['archivo_instrucciones']; ?>" target="_blank" class="btn-view">Archivo</a>
                            <?php else: ?>
                                <span class="no-file">Sin archivo</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="editar_tarea.php?tarea_id=<?php echo $tarea['id']; ?>" class="btn-edit" onclick="return confirm('¿Estás seguro de editar esta tarea?')">✏️ Editar</a>
                            <span class="btn-separator"></span>
                            <a href="../controllers/eliminar_tarea.php?tarea_id=<?php echo $tarea['id']; ?>" class="btn-delete" onclick="return confirm('¿Estás seguro de eliminar esta tarea?')">🗑️ Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="no-tasks">No has asignado tareas aún.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Botón para volver al Dashboard del Maestro -->
    <div class="back-to-dashboard">
        <a href="dashboard_maestro.php" class="btn-secondary">Regresar</a>
    </div>
</div>

<?php include '../partials/footer.php'; ?>

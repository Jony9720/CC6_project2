<?php
session_start();
include '../config/db.php';

// Verificar si el usuario es maestro
if ($_SESSION['rol'] !== 'maestro') {
    echo "Acceso denegado.";
    exit();
}

// Obtener el ID de la tarea a editar
$tarea_id = $_GET['tarea_id'];

// Consultar los datos de la tarea
$sql = "SELECT * FROM tareas WHERE id = :tarea_id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':tarea_id' => $tarea_id]);
$tarea = $stmt->fetch(PDO::FETCH_ASSOC);

// Si se envía el formulario para actualizar la tarea
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $fecha_entrega = $_POST['fecha_entrega'];
    $hora_entrega = $_POST['hora_entrega'];
    $archivo_ruta = $tarea['archivo_instrucciones'];

    // Procesar el archivo de instrucciones si se sube uno nuevo
    if (isset($_FILES['archivo_instrucciones']) && $_FILES['archivo_instrucciones']['error'] === 0) {
        $archivo_nombre = $_FILES['archivo_instrucciones']['name'];
        $archivo_tmp = $_FILES['archivo_instrucciones']['tmp_name'];
        $archivo_ruta = "../uploads/instrucciones/" . basename($archivo_nombre);

        // Mover el archivo
        if (!move_uploaded_file($archivo_tmp, $archivo_ruta)) {
            $_SESSION['error_message'] = "Error al subir el archivo de instrucciones.";
            header("Location: editar_tarea.php?tarea_id=$tarea_id");
            exit();
        }
    }

    // Actualizar los datos de la tarea en la base de datos
    $sql = "UPDATE tareas SET titulo = :titulo, descripcion = :descripcion, fecha_entrega = :fecha_entrega, 
            hora_entrega = :hora_entrega, archivo_instrucciones = :archivo_instrucciones WHERE id = :tarea_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':titulo' => $titulo,
        ':descripcion' => $descripcion,
        ':fecha_entrega' => $fecha_entrega,
        ':hora_entrega' => $hora_entrega,
        ':archivo_instrucciones' => $archivo_ruta,
        ':tarea_id' => $tarea_id
    ]);

    $_SESSION['success_message'] = "La tarea ha sido actualizada correctamente.";
    header("Location: ver_tareas_asignadas.php");
    exit();
}
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="task-edit-form card">
    <h2>Editar Tarea</h2>
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="form-group">
            <label for="titulo">Título de la Tarea:</label>
            <input type="text" name="titulo" id="titulo" value="<?php echo $tarea['titulo']; ?>" required>
        </div>

        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea name="descripcion" id="descripcion" required><?php echo $tarea['descripcion']; ?></textarea>
        </div>

        <div class="form-group">
            <label for="fecha_entrega">Fecha de Entrega:</label>
            <input type="date" name="fecha_entrega" id="fecha_entrega" value="<?php echo $tarea['fecha_entrega']; ?>" required>
        </div>

        <div class="form-group">
            <label for="hora_entrega">Hora de Entrega:</label>
            <input type="time" name="hora_entrega" id="hora_entrega" value="<?php echo $tarea['hora_entrega']; ?>" required>
        </div>

        <div class="form-group">
            <label for="archivo_instrucciones">Archivo de Instrucciones:</label>
            <input type="file" name="archivo_instrucciones" id="archivo_instrucciones" accept=".pdf, .zip">
            <?php if (!empty($tarea['archivo_instrucciones'])): ?>
                <p>Archivo Actual: <a href="<?php echo $tarea['archivo_instrucciones']; ?>" target="_blank">Ver Archivo</a></p>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn-primary">Actualizar Tarea</button>
        <a href="ver_tareas_asignadas.php" class="btn-secondary">Cancelar</a>
    </form>
</div>
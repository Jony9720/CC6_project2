<?php
session_start();
include '../config/db.php'; // Conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $envio_id = $_POST['envio_id'];
    $calificacion = $_POST['calificacion'];

    // Actualizar la calificación en la base de datos
    $sql = "UPDATE envios SET calificacion = :calificacion WHERE id = :envio_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':calificacion' => $calificacion, ':envio_id' => $envio_id]);

    // Obtener el ID del estudiante para generar la notificación
    $sql = "SELECT estudiante_id FROM envios WHERE id = :envio_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':envio_id' => $envio_id]);
    $envio = $stmt->fetch(PDO::FETCH_ASSOC);
    $estudiante_id = $envio['estudiante_id'];

    // Crear la notificación
    $mensaje = "Tu tarea ha sido calificada con una puntuación de $calificacion.";
    $sql = "INSERT INTO notificaciones (usuario_id, mensaje) VALUES (:usuario_id, :mensaje)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':usuario_id' => $estudiante_id, ':mensaje' => $mensaje]);

    echo "Calificación asignada y notificación generada correctamente.";
}
?>

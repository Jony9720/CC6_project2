<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mensaje = $_POST['mensaje'];
    $usuario_id = $_POST['usuario_id'];

    try {
        // Insertar notificación en la base de datos
        $sql = "INSERT INTO notificaciones (mensaje, usuario_id) VALUES (:mensaje, :usuario_id)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':mensaje' => $mensaje, ':usuario_id' => $usuario_id]);

        // Redireccionar con mensaje de éxito
        header('Location: ../views/enviar_notificacion.php?mensaje=Notificación enviada correctamente.');
        exit();
    } catch (PDOException $e) {
        // Manejar errores
        header('Location: ../views/enviar_notificacion.php?mensaje=Error al enviar la notificación.');
        exit();
    }
}
?>


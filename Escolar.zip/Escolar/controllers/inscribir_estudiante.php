<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $estudiante_id = $_POST['estudiante_id'];
    $curso_id = $_POST['curso_id'];

    // Verificar si el estudiante ya está inscrito en el curso
    $stmt = $pdo->prepare("SELECT * FROM inscripciones WHERE estudiante_id = :estudiante_id AND curso_id = :curso_id");
    $stmt->execute([':estudiante_id' => $estudiante_id, ':curso_id' => $curso_id]);
    $inscripcion = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$inscripcion) {
        // Insertar nueva inscripción
        $sql = "INSERT INTO inscripciones (estudiante_id, curso_id) VALUES (:estudiante_id, :curso_id)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':estudiante_id' => $estudiante_id, ':curso_id' => $curso_id]);
        echo "Estudiante inscrito correctamente.";
    } else {
        echo "El estudiante ya está inscrito en este curso.";
    }

    header('Location: ../views/inscribir_estudiante.php');
}
?>

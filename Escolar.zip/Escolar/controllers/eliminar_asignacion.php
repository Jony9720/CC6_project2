<?php
include '../config/db.php';

if (isset($_GET['asignacion_id'])) {
    $asignacion_id = $_GET['asignacion_id'];

    // Consulta para eliminar la asignación
    $sql = "DELETE FROM maestro_cursos WHERE id = :asignacion_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':asignacion_id' => $asignacion_id]);

    // Redireccionar de vuelta a la vista de asignar cursos
    header('Location: ../views/asignar_cursos.php');
    exit();
}
?>

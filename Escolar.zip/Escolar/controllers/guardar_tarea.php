<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $fecha_entrega = $_POST['fecha_entrega'];
    $hora_entrega = $_POST['hora_entrega'];
    $curso_id = $_POST['curso_id'];
    $maestro_id = $_SESSION['usuario_id'];
    $archivo_ruta = null;

    try {
        if (isset($_FILES['archivo_instrucciones']) && $_FILES['archivo_instrucciones']['error'] == 0) {
            $archivo_nombre = $_FILES['archivo_instrucciones']['name'];
            $archivo_tmp = $_FILES['archivo_instrucciones']['tmp_name'];
            $archivo_ruta = "../uploads/instrucciones/" . basename($archivo_nombre);

            // Verificar y mover el archivo
            if (!move_uploaded_file($archivo_tmp, $archivo_ruta)) {
                $_SESSION['error_message'] = "Error al subir el archivo de instrucciones.";
                header('Location: ../views/asignar_tarea.php');
                exit();
            }
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Error al procesar el archivo: " . $e->getMessage();
        header('Location: ../views/asignar_tarea.php');
        exit();
    }

    // Insertar la nueva tarea en la base de datos
    $sql = "INSERT INTO tareas (titulo, descripcion, fecha_entrega, hora_entrega, curso_id, maestro_id, archivo_instrucciones) 
                VALUES (:titulo, :descripcion, :fecha_entrega, :hora_entrega, :curso_id, :maestro_id, :archivo_ruta)";
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':titulo' => $titulo,
            ':descripcion' => $descripcion,
            ':fecha_entrega' => $fecha_entrega,
            ':hora_entrega' => $hora_entrega,
            ':curso_id' => $curso_id,
            ':maestro_id' => $maestro_id,
            ':archivo_ruta' => $archivo_ruta
        ]);

        // Establecer mensaje de éxito
        $_SESSION['success_message'] = "La tarea ha sido asignada correctamente.";
        header('Location: ../views/asignar_tarea.php'); // Redirigir al formulario de asignación
        exit();
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error al asignar la tarea: " . $e->getMessage();
        header('Location: ../views/asignar_tarea.php');
        exit();
    }
}
?>


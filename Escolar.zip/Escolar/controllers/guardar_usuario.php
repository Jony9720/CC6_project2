<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $rol = $_POST['rol'];
    $password = isset($_POST['password']) ? password_hash($_POST['password'], PASSWORD_BCRYPT) : null;
    $usuario_id = $_POST['usuario_id'];

    try {
        if ($usuario_id) {
            // Actualizar usuario existente
            $sql = "UPDATE usuarios SET nombre = :nombre, correo = :correo, rol = :rol";
            if ($password) {
                $sql .= ", password = :password";
            }
            $sql .= " WHERE id = :usuario_id";
            
            $stmt = $pdo->prepare($sql);
            $params = [
                ':nombre' => $nombre,
                ':correo' => $correo,
                ':rol' => $rol,
                ':usuario_id' => $usuario_id
            ];
            if ($password) {
                $params[':password'] = $password;
            }
            $stmt->execute($params);

            // Mensaje de éxito
            $_SESSION['success_message'] = "Usuario actualizado correctamente.";
        } else {
            // Crear nuevo usuario
            $sql = "INSERT INTO usuarios (nombre, correo, password, rol) VALUES (:nombre, :correo, :password, :rol)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nombre' => $nombre,
                ':correo' => $correo,
                ':password' => $password,
                ':rol' => $rol
            ]);

            // Mensaje de éxito
            $_SESSION['success_message'] = "Usuario creado correctamente.";
        }

        // Redireccionar a la página de gestión de usuarios
        header('Location: ../views/gestionar_usuarios.php');
        exit();
    } catch (PDOException $e) {
        // Mensaje de error
        $_SESSION['error_message'] = "Error al procesar el usuario: " . $e->getMessage();
        header('Location: ../views/gestionar_usuarios.php');
        exit();
    }
}
?>

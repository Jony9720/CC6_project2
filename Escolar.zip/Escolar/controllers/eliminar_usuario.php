<?php
session_start();
include '../config/db.php';

if (isset($_GET['usuario_id'])) {
    $usuario_id = $_GET['usuario_id'];

    // Eliminar el usuario
    $sql = "DELETE FROM usuarios WHERE id = :usuario_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':usuario_id' => $usuario_id]);

    echo "Usuario eliminado correctamente.";
    header('Location: ../views/gestionar_usuarios.php');
}
?>

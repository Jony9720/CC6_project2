<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $curso_id = $_POST['curso_id'];
    $tipo = $_POST['tipo'];
    $maestro_id = $_SESSION['usuario_id'];

    try {
        if ($tipo == 'archivo') {
            $archivo_nombre = $_FILES['archivo']['name'];
            $archivo_tmp = $_FILES['archivo']['tmp_name'];
            $archivo_ruta = "../uploads/material/" . basename($archivo_nombre);

            if (move_uploaded_file($archivo_tmp, $archivo_ruta)) {
                $sql = "INSERT INTO material (titulo, descripcion, tipo, archivo_ruta, curso_id, maestro_id)
                        VALUES (:titulo, :descripcion, :tipo, :archivo_ruta, :curso_id, :maestro_id)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':titulo' => $titulo,
                    ':descripcion' => $descripcion,
                    ':tipo' => $tipo,
                    ':archivo_ruta' => $archivo_ruta,
                    ':curso_id' => $curso_id,
                    ':maestro_id' => $maestro_id
                ]);
                $_SESSION['success_message'] = "Material subido correctamente.";
            } else {
                $_SESSION['error_message'] = "Error al subir el archivo.";
            }
        } elseif ($tipo == 'enlace') {
            $enlace = $_POST['enlace'];

            // Expresión regular mejorada para validar enlaces
            $regex = "/^(https?:\/\/)(www\.)?[a-zA-Z0-9-]+(\.[a-zA-Z]{2,6})(\/[a-zA-Z0-9#?&%=._-]*)?$/";

            if (filter_var($enlace, FILTER_VALIDATE_URL) === false || !preg_match($regex, $enlace)) {
                $_SESSION['error_message'] = "El enlace ingresado no es válido. Asegúrate de que comience con 'http://' o 'https://' y tenga un dominio válido (por ejemplo, '.com', '.org').";
                header('Location: ../views/subir_material.php');
                exit();
            }


            $sql = "INSERT INTO material (titulo, descripcion, tipo, enlace, curso_id, maestro_id)
                    VALUES (:titulo, :descripcion, :tipo, :enlace, :curso_id, :maestro_id)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':titulo' => $titulo,
                ':descripcion' => $descripcion,
                ':tipo' => $tipo,
                ':enlace' => $enlace,
                ':curso_id' => $curso_id,
                ':maestro_id' => $maestro_id
            ]);
            $_SESSION['success_message'] = "Enlace subido correctamente.";
        }
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error al guardar el material: " . $e->getMessage();
    }

    header('Location: ../views/subir_material.php');
    exit();
}
?>

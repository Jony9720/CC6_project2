<?php
session_start();
include '../config/db.php';

$error = ''; // Variable para el mensaje de error

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    // Consulta para obtener el usuario
    $sql = "SELECT * FROM usuarios WHERE correo = :correo";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':correo' => $correo]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario && password_verify($password, $usuario['password'])) {
        // Establecer variables de sesión
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['rol'] = $usuario['rol'];
        $_SESSION['nombre'] = $usuario['nombre'];

        // Redirigir a un dashboard específico según el rol
        if ($usuario['rol'] == 'admin') {
            header('Location: ../views/dashboard_admin.php');
        } elseif ($usuario['rol'] == 'maestro') {
            header('Location: ../views/dashboard_maestro.php');
        } elseif ($usuario['rol'] == 'estudiante') {
            header('Location: ../views/dashboard_estudiante.php');
        }
    } else {
        $error = "Correo o contraseña incorrectos.";
        $_SESSION['error'] = $error;
        header('Location: ../views/login.php');
        exit();
    }
}
?>

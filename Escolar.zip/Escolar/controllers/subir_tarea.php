<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tarea_id = $_POST['tarea_id'];
    $estudiante_id = $_SESSION['usuario_id'];

    // Verificar si el estudiante está inscrito en el curso de la tarea seleccionada
    $sql = "SELECT inscripciones.*, cursos.nombre AS curso_nombre 
            FROM inscripciones 
            JOIN tareas ON inscripciones.curso_id = tareas.curso_id
            JOIN cursos ON tareas.curso_id = cursos.id
            WHERE inscripciones.estudiante_id = :estudiante_id AND tareas.id = :tarea_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([':estudiante_id' => $estudiante_id, ':tarea_id' => $tarea_id]);
    $curso = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$curso) {
        $mensaje = "No estás inscrito en el curso asociado a esta tarea.";
        $tipo_mensaje = "error";
    } else {
        // Procesar la subida del archivo
        $archivo = $_FILES['archivo'];
        $archivo_nombre = $archivo['name'];
        $archivo_tmp = $archivo['tmp_name'];
        $archivo_destino = "../uploads/" . basename($archivo_nombre);

        if (move_uploaded_file($archivo_tmp, $archivo_destino)) {
            // Insertar el registro en la base de datos para la tarea entregada
            $sql = "INSERT INTO envios (tarea_id, estudiante_id, archivo_ruta, curso_nombre, fecha_envio)
                    VALUES (:tarea_id, :estudiante_id, :archivo_ruta, :curso_nombre, NOW())";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':tarea_id' => $tarea_id,
                ':estudiante_id' => $estudiante_id,
                ':archivo_ruta' => $archivo_destino,
                ':curso_nombre' => $curso['curso_nombre']
            ]);

            $mensaje = "Tarea enviada correctamente para el curso: " . $curso['curso_nombre'];
            $tipo_mensaje = "success";
        } else {
            $mensaje = "Error al subir el archivo.";
            $tipo_mensaje = "error";
        }
    }
}
?>

<link rel="stylesheet" href="../css/styles.css">

<div class="message-container">
    <div class="message <?php echo $tipo_mensaje; ?>">
        <?php echo $mensaje; ?>
    </div>
    <div class="back-to-dashboard">
        <a href="../views/dashboard_estudiante.php" class="btn-secondary">Volver al Dashboard</a>
    </div>
</div>

<?php include '../partials/footer.php'; ?>


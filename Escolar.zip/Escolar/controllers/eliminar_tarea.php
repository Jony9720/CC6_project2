<?php
session_start();
include '../config/db.php';

// Verificar si el usuario es maestro
if ($_SESSION['rol'] !== 'maestro') {
    echo "Acceso denegado.";
    exit();
}

// Obtener el ID de la tarea a eliminar
$tarea_id = $_GET['tarea_id'] ?? null;

if ($tarea_id) {
    try {
        // Eliminar la tarea de la base de datos
        $sql = "DELETE FROM tareas WHERE id = :tarea_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':tarea_id' => $tarea_id]);

        // Mensaje de éxito
        $_SESSION['success_message'] = "Tarea eliminada correctamente.";
    } catch (PDOException $e) {
        // Mensaje de error
        $_SESSION['error_message'] = "Error al eliminar la tarea: " . $e->getMessage();
    }
}

// Redirigir a la vista de ver tareas asignadas
header('Location: ../views/ver_tareas_asignadas.php');
exit();
?>

<?php
session_start();
include '../config/db.php';

if (isset($_GET['inscripcion_id'])) {
    $inscripcion_id = $_GET['inscripcion_id'];

    // Eliminar la inscripción
    $sql = "DELETE FROM inscripciones WHERE id = :inscripcion_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':inscripcion_id' => $inscripcion_id]);

    echo "Inscripción eliminada correctamente.";
    header('Location: ../views/inscribir_estudiante.php');
}
?>

<?php
session_start();
include '../config/db.php';

if (isset($_GET['notificacion_id'])) {
    $notificacion_id = $_GET['notificacion_id'];

    // Marcar la notificación como leída
    $sql = "UPDATE notificaciones SET leida = 1 WHERE id = :notificacion_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':notificacion_id' => $notificacion_id]);

    echo "Notificación marcada como leída.";
    header('Location: ../views/ver_notificaciones.php');
}
?>

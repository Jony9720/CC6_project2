<?php
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $maestro_id = $_POST['maestro_id'];
    $curso_id = $_POST['curso_id'];

    // Verificar si la asignación ya existe
    $checkSql = "SELECT * FROM maestro_cursos WHERE maestro_id = :maestro_id AND curso_id = :curso_id";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->execute([
        ':maestro_id' => $maestro_id,
        ':curso_id' => $curso_id
    ]);

    if ($checkStmt->rowCount() > 0) {
        // Redirigir directamente si ya existe la asignación
        header("Location: ../views/asignar_cursos.php?error=duplicado");
        exit();
    } else {
        // Insertar la asignación si no existe
        $sql = "INSERT INTO maestro_cursos (maestro_id, curso_id) VALUES (:maestro_id, :curso_id)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':maestro_id' => $maestro_id,
            ':curso_id' => $curso_id
        ]);

        // Redirigir a la página de asignar cursos
        header("Location: ../views/asignar_cursos.php?success=true");
        exit();
    }
}
?>


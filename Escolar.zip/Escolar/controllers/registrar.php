<?php
session_start();
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $rol = $_POST['rol'];

    // Insertar el nuevo usuario en la base de datos
    $sql = "INSERT INTO usuarios (nombre, correo, password, rol) VALUES (:nombre, :correo, :password, :rol)";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([
            ':nombre' => $nombre,
            ':correo' => $correo,
            ':password' => $password,
            ':rol' => $rol
        ]);

        // Mensaje de éxito
        $_SESSION['success'] = "Usuario registrado exitosamente.";
        header('Location: ../views/login.php');
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error al registrar el usuario: " . $e->getMessage();
        header('Location: ../views/registro.php');
        exit();
    }
}
?>


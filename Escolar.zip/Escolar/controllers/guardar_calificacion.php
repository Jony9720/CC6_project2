<?php
session_start();
include '../config/db.php';

if ($_SESSION['rol'] !== 'maestro') {
    echo "Acceso denegado.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $envio_id = $_POST['envio_id'];
    $calificacion = $_POST['calificacion'];
    $comentarios = $_POST['comentarios'];

    $sql = "UPDATE envios SET calificacion = :calificacion, comentarios = :comentarios WHERE id = :envio_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':calificacion' => $calificacion,
        ':comentarios' => $comentarios,
        ':envio_id' => $envio_id
    ]);

    $_SESSION['success_message'] = "Calificación guardada correctamente.";
    header('Location: ../views/calificar_tarea.php');
    exit();
}


<?php
session_start();
include '../config/db.php';

// Verificar si el usuario es administrador
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    $_SESSION['error_message'] = "Acceso denegado. Solo los administradores pueden eliminar cursos.";
    header('Location: ../views/gestionar_cursos.php');
    exit();
}

// Obtener el ID del curso a eliminar
$curso_id = $_GET['curso_id'] ?? null;

if ($curso_id) {
    try {
        // Eliminar el curso de la base de datos
        $sql = "DELETE FROM cursos WHERE id = :curso_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':curso_id' => $curso_id]);

        // Mensaje de éxito
        $_SESSION['success_message'] = "Curso eliminado correctamente.";
    } catch (PDOException $e) {
        // Mensaje de error
        $_SESSION['error_message'] = "Error al eliminar el curso: " . $e->getMessage();
    }
}

// Redirigir a la vista de gestión de cursos
header('Location: ../views/gestionar_cursos.php');
exit();
?>

<?php
include '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $curso_id = $_POST['curso_id'];

    try {

        if ($curso_id) {
            // Actualizar curso existente
            $sql = "UPDATE cursos SET nombre = :nombre, descripcion = :descripcion WHERE id = :curso_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nombre' => $nombre,
                ':descripcion' => $descripcion,
                ':curso_id' => $curso_id
            ]);
            // Mensaje de éxito
            $_SESSION['success_message'] = "Curso actualizado correctamente.";
        } else {
            // Crear nuevo curso
            $sql = "INSERT INTO cursos (nombre, descripcion) VALUES (:nombre, :descripcion)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nombre' => $nombre,
                ':descripcion' => $descripcion
            ]);
            // Mensaje de éxito
            $_SESSION['success_message'] = "Curso creado correctamente.";
        }
        header('Location: ../views/gestionar_cursos.php');
        exit();

    } catch (PDOException $e) {
        // Mensaje de error
        $_SESSION['error_message'] = "Error al procesar el curso: " . $e->getMessage();
        header('Location: ../views/gestionar_cursos.php');
        exit();
    }
}
?>

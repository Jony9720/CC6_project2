<?php
session_start();
include '../config/db.php';

// Verificar si el usuario es maestro
if ($_SESSION['rol'] !== 'maestro') {
    echo "Acceso denegado.";
    exit();
}

// Obtener el ID del material a eliminar
$material_id = $_GET['material_id'] ?? null;

if ($material_id) {
    try {
        // Eliminar el material de la base de datos
        $sql = "DELETE FROM material WHERE id = :material_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':material_id' => $material_id]);

        // Redirigir con mensaje de éxito
        header('Location: ../views/ver_material_maestro.php?message=success&text=Material eliminado correctamente');
    } catch (PDOException $e) {
        // Redirigir con mensaje de error
        header('Location: ../views/ver_material_maestro.php?message=error&text=Error al eliminar el material: ' . urlencode($e->getMessage()));
    }
    exit();
}
?>